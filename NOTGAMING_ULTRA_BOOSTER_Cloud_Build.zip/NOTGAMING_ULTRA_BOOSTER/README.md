# NOTGAMING ULTRA BOOSTER — starter Android project

This is the first installable-project foundation for the Samsung Galaxy A21s / Android 12.

## Included
- Nothing OS-inspired black / white / red interface
- Performance, Balanced and Power Save profile selection (UI presets only)
- Installed launcher-app discovery, including sideloaded APK apps
- Launch buttons for detected apps
- Honest tool/device information screens

## Important limitations
This starter app does not overclock the CPU/GPU, promise extra FPS, or show fake FPS values.
Screen recording is not implemented in this first build; use Samsung's built-in Screen Recorder.
Android may restrict visibility of some installed packages depending on OS version and policy.

## Build
1. Install Android Studio on your Windows PC.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `NOTGAMING_ULTRA_BOOSTER` folder.
4. Allow Gradle sync to finish.
5. Connect your phone with USB debugging enabled, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be created under `app/build/outputs/apk/debug/`.

Package: `com.notgaming.ultrabooster`
Minimum Android: 6.0 (API 23)
Target Android: 12 (API 32)
